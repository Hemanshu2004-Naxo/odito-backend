=== Odito SEO Bridge ===
Contributors: odito
Tags: seo, rank math, yoast, seopress, aioseo, api
Requires at least: 5.6
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.6.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lets Odito read and apply on-page SEO fixes through whichever supported SEO plugin is active on your site.

== Description ==

Odito audits your site's SEO and AI-visibility, and can apply certain fixes
directly — title tags, meta descriptions, canonical URLs, and robots meta
(index/noindex, follow/nofollow) on a per-page basis, plus (Rank Math only,
currently) site-wide fixes: adding a social profile URL to your
Organization schema's sameAs property, and enabling breadcrumb structured
data. WordPress's own REST API does not expose write access to these
fields for most SEO plugins (Rank Math and Yoast SEO in particular
register no writable REST field for them at all). This plugin closes that
gap: running as ordinary WordPress PHP code, it can safely read and write
these fields using each SEO plugin's own documented storage mechanism.

Supported SEO plugins:

* All in One SEO (AIOSEO)
* SEOPress
* Rank Math SEO
* Yoast SEO

If more than one supported SEO plugin is active at the same time, the
Bridge refuses to guess which one to use — it reports the ambiguity to
Odito rather than writing to the wrong plugin's fields.

FAQ structured data: when a page already shows an FAQ but has no FAQPage
schema, Odito can apply FAQPage JSON-LD built from that page's own visible
questions and answers. This works with any SEO plugin, or none. The Bridge
keeps the question/answer pairs in one post-meta key of its own
(`_odito_faq_pairs`) and prints the JSON-LD in the page's <head>; it never edits
your post content or any SEO plugin's data. If the post already contains a
Rank Math or Yoast FAQ block the Bridge prints nothing, so FAQPage markup is
never duplicated. Sites can also opt a post out with the
`odito_seo_bridge_render_faq_schema` filter.

AggregateRating structured data: when a page displays a rating and review
count but has no AggregateRating markup, Odito can apply the rating shown on
the page to an entity that already exists in the page's own schema (a Product,
Service, LocalBusiness or Organization). The rating is merged into that entity
by its @id — inside Rank Math's or Yoast SEO's own JSON-LD where they expose it,
otherwise as a node carrying that same @id — never as an unrelated new entity.
The validated target and rating are kept in one post-meta key of the Bridge's own
(`_odito_aggregate_rating`). Sites can opt a post out with the
`odito_seo_bridge_render_rating_schema` filter.

This plugin does not store any credentials. Authentication happens through
a standard WordPress Application Password that you generate for your own
account and provide to Odito directly — this plugin only enforces that the
authenticated user has permission to edit the specific post being changed.

This plugin is independent of, and does not interact with, the separate
Odito Lead Capture plugin.

== Installation ==

1. Upload the `odito-seo-bridge` folder to `/wp-content/plugins/`, or
   install the zip through Plugins → Add New → Upload Plugin.
2. Activate the plugin.
3. Make sure exactly one of the supported SEO plugins (AIOSEO, SEOPress,
   Rank Math, or Yoast SEO) is active.
4. In your WordPress profile, create an Application Password and provide
   it to Odito when connecting your site.

== Frequently Asked Questions ==

= Does this plugin work without an SEO plugin installed? =

The Bridge itself will report that no supported provider is active, and
Odito will fall back to whatever it can already read/write through core
WordPress fields.

= What happens if I have two SEO plugins active? =

The Bridge reports this as an ambiguous state and will not read or write
SEO fields until only one supported plugin is active.

== Changelog ==

= 1.6.0 =
* Organization address (Rank Math): the structured Local SEO postal address (street, city, region, postal code, country) can
  now be read and written through PUT /odito/v1/seo/site (entity organization, field address). The value is a JSON object
  whose only accepted keys are those five; unknown keys, markup and control characters are refused, and a street and a city
  are required. The write is a single conditional (compare-and-set) update of the settings row: with an expected address it is
  refused (HTTP 409 expected_mismatch) unless the stored address is still the one that was read, and op "clear" (with
  expected) restores an empty address for rollback. Only the local_address key changes. Rank Math publishes the address
  only while its Local SEO module is on; the site-level GET reports that, and the address read-back.
* /status reports supports.organization_address.
* Not changed: every other field keeps its behaviour.

= 1.5.0 =
* Reliability: Organization site-level writes (name, description, url, logo, organization type) are now
  compare-and-set at the database level. The expected value is checked inside one conditional SQL UPDATE of
  Rank Math's settings row, so a setting saved by someone else between Odito's read and write is never
  overwritten, and a concurrent save of a different Rank Math setting is not silently undone (bounded retries,
  then HTTP 409). Conflicts return a machine reason (expected_mismatch, contention).
* Media alt text: new GET/PUT /odito/v1/media/<id>/alt (media alt text) writes ONE attachment's alt text only.
  The request cannot name a field or meta key; the attachment must be an image the user may edit, its file must
  still be the file that was approved (otherwise HTTP 409 target_changed), and the stored alt is compared inside a
  single conditional UPDATE. A repeated identical request reports alreadyApplied instead of failing.
* Writes report an operation id and whether they were conditional, for Odito's audit trail.
* /status reports supports.media_alt.
* Not changed: sameAs and breadcrumb writes remain read-then-write (not conditional); creating an alt-text row that
  does not exist yet has a small check-then-insert window (documented, never overwrites an existing value).

= 1.4.0 =
* Organization identity (Rank Math): the organization-type setting (Local SEO business type,
  e.g. "Hospital") can now be read and written through PUT /odito/v1/seo/site
  (entity organization, field type). Only a type from Rank Math's own list is accepted, and only
  while the site is configured as a company. The site-level GET now also reports the
  organization type, whether the site is a company or a person, and whether an address is set.
* Organization site-level writes accept an optional "expected" value (compare-and-set): the write
  is refused with HTTP 409 if the stored value changed since it was read, so a fix or its rollback
  never overwrites a newer edit. op "clear" (with expected) restores a field to empty.
* Writing the organization logo URL now also updates the logo attachment id, so the published
  logo dimensions can never belong to a previous logo.
* The site-level GET also reports whether Rank Math's Local SEO module is active (without it a stored
  organization type is never published).
* /status reports supports.organization_type.

= 1.3.1 =
* Hardening: URLs written to site-level schema (Organization sameAs, url, logo) and to the
  canonical field are now rejected if they contain whitespace, line breaks, control
  characters, quotes, or backslashes. Rank Math stores additional social profiles one per
  line, so a URL containing a line break could otherwise have added an unintended extra profile.
* No new capabilities and no REST changes; sites already on 1.3.0 keep every capability.

= 1.3.0 =
* Added per-page AggregateRating structured data (GET/PUT
  /odito/v1/rating-schema/{postId}, same edit_post gate as the other per-post
  routes). Validated strictly (entity with absolute @id + @type + name; rating
  inside its scale with a review or rating count); only the validated
  target and rating are stored and everything printed is rebuilt from them.
* Merges into the matching entity of Rank Math (`rank_math/json_ld`) or Yoast
  SEO (`wpseo_schema_graph`) when present; otherwise prints a node with the
  same @id.
* /status now reports supports.rating_schema. It does not depend on the active
  SEO plugin.
* The plugin now also owns the post-meta key `_odito_aggregate_rating`,
  removed on uninstall.

= 1.2.0 =
* Added per-page FAQPage structured data (GET/PUT /odito/v1/faq-schema/{postId},
  gated by the same edit_post check as the other per-post routes). The
  request is validated strictly (a FAQPage whose every entry is a Question
  with a non-empty name and accepted-answer text, at most 50 entries); only
  the validated question/answer pairs are stored, and the JSON-LD that is
  printed is always rebuilt from them.
* /status now reports supports.faq_schema so older Bridge versions are never
  assumed to have this capability. It does not depend on the active SEO plugin.
* The plugin now owns one post-meta key (`_odito_faq_pairs`), which is removed
  when the plugin is uninstalled.

= 1.1.0 =
* Added robots meta (index/noindex, follow/nofollow) support — Rank Math only.
* Added site-level schema support (Rank Math only): adding a social profile
  URL to Organization sameAs (never overwrites Facebook/Twitter-derived
  profiles), and enabling breadcrumb structured data.
* New site-level REST routes (GET/PUT /odito/v1/seo/site), gated behind
  manage_options rather than the per-post edit_post check.
* /status now reports supports.site_schema so older Bridge versions are
  never assumed to have this capability.

= 1.0.0 =
* Initial release. Supports AIOSEO, SEOPress, Rank Math, and Yoast SEO for
  title, meta description, and canonical URL.
