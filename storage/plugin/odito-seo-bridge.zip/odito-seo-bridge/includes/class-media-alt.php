<?php
namespace Odito\SeoBridge;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Conditional update of ONE media attachment's alt text (post meta `_wp_attachment_image_alt`) — and nothing else.
 *
 * The caller cannot name a field: the meta key is fixed here. It names an attachment id, the value it expects to find, the new
 * value, and the attachment's own file path (`_wp_attached_file`) as the identity it approved. The Bridge re-validates all of it:
 *   - the post is an image attachment the current user may edit (edit_post),
 *   - its file is still the file that was approved (a replaced image is refused),
 *   - the stored alt is still the expected one — compared inside a single conditional SQL UPDATE, so a change made by anyone else
 *     between Odito's read and this write matches zero rows and nothing is written.
 *
 * Residual window, stated plainly: when the attachment has NO alt row yet, creation uses add_post_meta(..., unique=true), which checks
 * for an existing row and then inserts. post meta has no unique key, so two requests creating the row at the exact same moment could
 * both succeed. That needs two writers inside the same few milliseconds on a brand-new row; the read-back that follows every write
 * detects it, and it never overwrites an existing value.
 */
class Media_Alt {

	const META_KEY   = '_wp_attachment_image_alt';
	const MAX_LENGTH = 250;

	/** @return \WP_Post|null an image attachment, or null */
	public static function attachment( int $id ) {
		$post = get_post( $id );
		if ( ! $post || 'attachment' !== $post->post_type || ! wp_attachment_is_image( $id ) ) {
			return null;
		}
		return $post;
	}

	/** Alt text validation mirrored from Odito: plain text, bounded, no control characters. @return true|string */
	public static function validate_value( string $value ) {
		if ( strlen( $value ) > self::MAX_LENGTH * 4 || mb_strlen( $value ) > self::MAX_LENGTH ) {
			return 'The alt text is too long.';
		}
		if ( false !== strpos( $value, '<' ) || false !== strpos( $value, '>' ) ) {
			return 'The alt text must be plain text, never HTML markup.';
		}
		if ( preg_match( '/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', $value ) ) {
			return 'The alt text cannot contain control characters.';
		}
		return true;
	}

	/** @return array{id:int,alt:string,file:string} */
	public static function read( int $id ): array {
		return array(
			'id'   => $id,
			'alt'  => (string) get_post_meta( $id, self::META_KEY, true ),
			'file' => (string) get_post_meta( $id, '_wp_attached_file', true ),
		);
	}

	/**
	 * @return array{id:int,alt:string,file:string,operation:array{id:string,atomic:bool,alreadyApplied:bool,created:bool}}
	 * @throws Conflict_Exception when the file, the stored alt or the row structure is not what the caller approved
	 */
	public static function swap( int $id, string $expected, string $value, string $expected_file ): array {
		global $wpdb;
		$operation = array( 'id' => Atomic::operation_id(), 'atomic' => true, 'alreadyApplied' => false, 'created' => false );

		$file = (string) get_post_meta( $id, '_wp_attached_file', true );
		if ( '' === $expected_file || $file !== $expected_file ) {
			throw new Conflict_Exception( 'The attachment is no longer the image that was approved, so nothing was written.', 'target_changed' );
		}

		$rows_found = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s", $id, self::META_KEY ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( $rows_found > 1 ) {
			throw new Conflict_Exception( 'This attachment has more than one alt-text record, so it cannot be changed safely.', 'ambiguous_meta' );
		}

		if ( 0 === $rows_found ) {
			// WordPress and Odito both treat "no alt text" as empty: only an empty expectation matches a missing row.
			if ( '' !== $expected ) {
				throw new Conflict_Exception( 'The alt text changed since it was read, so it was not overwritten.', 'expected_mismatch' );
			}
			if ( '' === $value ) {
				$operation['alreadyApplied'] = true;
			} else {
				$meta_id = add_post_meta( $id, self::META_KEY, wp_slash( $value ), true );
				if ( ! $meta_id ) {
					throw new Conflict_Exception( 'The alt text was created by someone else at the same moment, so it was not overwritten.', 'expected_mismatch' );
				}
				$operation['atomic']  = false; // see the class docblock
				$operation['created'] = true;
			}
		} else {
			$rows = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->postmeta} SET meta_value = %s WHERE post_id = %d AND meta_key = %s AND meta_value = %s", $value, $id, self::META_KEY, $expected ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			if ( false === $rows ) {
				throw new \Exception( 'The alt text could not be written.' );
			}
			if ( 0 === (int) $rows ) {
				$current = (string) $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s", $id, self::META_KEY ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				if ( $current !== $value ) {
					throw new Conflict_Exception( 'The alt text changed since it was read, so it was not overwritten.', 'expected_mismatch' );
				}
				$operation['alreadyApplied'] = true; // somebody (a retry of this very change) already stored exactly this value
			} else {
				$meta_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT meta_id FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s", $id, self::META_KEY ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				wp_cache_delete( $id, 'post_meta' );
				clean_post_cache( $id );
				do_action( 'updated_post_meta', $meta_id, $id, self::META_KEY, $value );
			}
		}

		wp_cache_delete( $id, 'post_meta' );
		$saved = self::read( $id );
		return $saved + array( 'operation' => $operation );
	}
}
