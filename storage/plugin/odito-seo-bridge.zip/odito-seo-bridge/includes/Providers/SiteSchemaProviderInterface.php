<?php
namespace Odito\SeoBridge\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Optional second interface for providers that support SITE-LEVEL schema
 * (Organization/Knowledge Graph, breadcrumbs) in addition to the required
 * per-post ProviderInterface. Deliberately separate rather than added to
 * ProviderInterface itself: Yoast/AIOSEO/SEOPress providers implement only
 * ProviderInterface today (their site-level schema storage has not been
 * confirmed the way Rank Math's has), and making these methods mandatory on
 * ProviderInterface would force every provider class to either implement
 * unverified behavior or throw — an instanceof check at the call site
 * (see Rest_Controller) is the correct way to make this genuinely optional.
 */
interface SiteSchemaProviderInterface {

	/**
	 * @return array{organization: array{name: string, description: string, url: string, logo: string, sameAs: string[]}, breadcrumbs: array{enabled: bool}}
	 */
	public function get_site_schema(): array;

	/**
	 * @param string      $entity 'organization' or 'breadcrumbs'
	 * @param string      $field  one of Security::SITE_SCHEMA_ENTITIES[$entity]
	 * @param string|bool $value  already sanitized AND shape-validated by the caller
	 * @param string|null $op     'add'|'remove' — required for organization.sameAs
	 * @param string|null $expected for the scalar organization fields: the stored value the caller read. When given, the change is
	 *                            applied only if the CURRENT stored value still equals it (compared inside the database write).
	 * @return bool true on success
	 * @throws \Odito\SeoBridge\Conflict_Exception when $expected no longer holds (nothing was changed)
	 * @throws \Exception if this field cannot be written
	 */
	public function update_site_schema_field( string $entity, string $field, $value, ?string $op = null, ?string $expected = null ): bool;
}
