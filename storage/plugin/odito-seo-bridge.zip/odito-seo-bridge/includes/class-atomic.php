<?php
namespace Odito\SeoBridge;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A change was refused because the stored value is not the one the caller expected. Nothing was changed.
 */
class Conflict_Exception extends \Exception {

	/** @var string a stable machine reason: expected_mismatch | target_changed | ambiguous_meta | contention */
	public $reason;

	public function __construct( string $message, string $reason = 'expected_mismatch' ) {
		parent::__construct( $message );
		$this->reason = $reason;
	}
}

/**
 * Database-level conditional updates for the values Odito changes.
 *
 * WordPress's own update_option()/update_post_meta() read a value, decide, then write — another request can change it in between,
 * and Rank Math keeps ALL its title/knowledge-graph settings in ONE serialized option row, so a read-modify-write of that row can
 * silently undo a concurrent save of a different setting. These helpers close that window with a single conditional SQL statement:
 *
 *   UPDATE ... SET value = <new> WHERE <key> AND value = <exactly what we read>
 *
 * The database applies it atomically: if anything else changed the value after our read, it matches zero rows and nothing is
 * written. The caller then re-reads and decides again (bounded), or reports a conflict.
 *
 * What this does NOT guarantee (stated plainly): it cannot stop an editor changing the value one moment AFTER our write (that is a
 * normal later edit), it does not serialize against code that bypasses the database layer, and creating a row that does not exist yet
 * (post meta has no unique key) still has a small check-then-insert window — see Media_Alt::swap().
 */
class Atomic {

	const MAX_ATTEMPTS = 4;

	/**
	 * Compare-and-swap a whole option through a mutator. The mutator receives the CURRENT array and returns the new one; it throws
	 * Conflict_Exception when the caller's expected value no longer holds. Returns the attempt number that succeeded (1 = first try).
	 *
	 * @throws Conflict_Exception when the option keeps changing under us (reason `contention`) or the mutator refuses.
	 * @throws \Exception on a database error.
	 */
	public static function swap_option( string $name, callable $mutate, int $max_attempts = self::MAX_ATTEMPTS ): int {
		global $wpdb;

		for ( $attempt = 1; $attempt <= $max_attempts; $attempt++ ) {
			$raw = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $name ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			if ( null === $raw ) {
				// No row yet: add_option() relies on the unique option_name key, so two creators cannot both succeed.
				$new = $mutate( array() );
				if ( add_option( $name, $new ) ) {
					return $attempt;
				}
				continue;
			}

			$current = maybe_unserialize( $raw );
			$current = is_array( $current ) ? $current : array();
			$new     = $mutate( $current );
			if ( $new === $current ) {
				return $attempt; // nothing to change
			}

			$new_raw = maybe_serialize( $new );
			$rows    = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s", $new_raw, $name, $raw ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			if ( false === $rows ) {
				throw new \Exception( 'The settings could not be written.' );
			}
			if ( 1 === (int) $rows ) {
				wp_cache_delete( $name, 'options' );
				wp_cache_delete( 'alloptions', 'options' );
				wp_cache_delete( 'notoptions', 'options' );
				do_action( "update_option_{$name}", $current, $new, $name );
				do_action( 'updated_option', $name, $current, $new );
				return $attempt;
			}
			// 0 rows: somebody else saved this option after we read it. Re-read and decide again.
		}

		throw new Conflict_Exception( 'This setting is being changed by someone else right now, so it was not written. Try again.', 'contention' );
	}

	/** A random operation identifier for the audit trail (never derived from a secret). */
	public static function operation_id(): string {
		return function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : bin2hex( random_bytes( 16 ) );
	}
}
